# DrainGuard Brand Asset Kit

This kit contains production-oriented, editable SVG logo assets, favicon/app icon sizes, a web manifest, and reusable CSS design tokens.

## What's included

### Vector logo assets — `public/assets/`
- `drainguard-logo.svg` — horizontal logo for light surfaces.
- `drainguard-logo-dark.svg` — horizontal logo for dark surfaces.
- `drainguard-logo-mono.svg` — single-color horizontal logo for documents/mono printing.
- `drainguard-logo-tagline.svg` — horizontal logo with “Smarter Cities. Safer Streets.” for larger placements.
- `drainguard-logo-tagline-dark.svg` — tagline lockup for dark surfaces.
- `drainguard-icon.svg` — standalone water / urban-grid / D-flow symbol, transparent background.
- `drainguard-icon-mono.svg` — monochrome standalone symbol.
- `favicon.svg` — square favicon artwork with Midnight Ink background.

### Raster favicon and app icon assets — `public/assets/`
- `favicon.ico` — multi-size browser icon (16, 32, 48 px).
- `favicon-16x16.png`, `favicon-32x32.png`, `favicon-48x48.png`, `favicon-64x64.png`.
- `apple-touch-icon.png` — 180 × 180 px.
- `android-chrome-192x192.png`, `android-chrome-512x512.png`.
- `drainguard-icon-128.png`, `drainguard-icon-256.png`, `drainguard-icon-512.png` — transparent standalone mark.
- `drainguard-logo-preview.png`, `drainguard-logo-dark-preview.png`, `drainguard-logo-tagline-preview.png` — raster previews for quick inspection.

### Root files
- `site.webmanifest` — PWA icon metadata; copy to your app's public root if the framework expects it there.
- `drainguard-brand.css` — official CSS custom properties and semantic tokens.
- `README.md` — this guide.

## Official core palette

| Name | Hex | Use |
|---|---|---|
| Midnight Ink | `#0B1220` | Primary dark brand, deep structure |
| Deep Harbor | `#142235` | Secondary dark surfaces |
| Electric Aqua | `#20D6C2` | Primary accent and interaction |
| Rain Cyan | `#38BDF8` | Water/weather information accent |
| Cloud White | `#F8FAFC` | Light page surfaces |
| Urban Mist | `#E2E8F0` | Borders and subtle surfaces |
| Slate | `#64748B` | Secondary text on light surfaces |

### Operational risk colors
- Low: `#34D399`
- Elevated: `#F5B942`
- High: `#FB7185`
- Critical: `#EF4444`

Risk states should always be accompanied by a text label or symbol; never rely on color alone.

## Basic integration

Use the SVG directly in the app shell:

```html
<img src="/assets/drainguard-logo.svg" alt="DrainGuard" />
```

For favicon metadata, reference the path that matches your app's routing/framework:

```html
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml" />
<link rel="icon" href="/assets/favicon.ico" sizes="any" />
<link rel="apple-touch-icon" href="/assets/apple-touch-icon.png" />
<link rel="manifest" href="/site.webmanifest" />
```

The `site.webmanifest` file is at the kit root for convenient integration. If your framework serves static files from `public/`, copy it to that directory and ensure its icon paths match the actual public URLs.

Import `drainguard-brand.css` into the existing global stylesheet or port the variables into the current Tailwind theme. Do not replace the existing Tailwind configuration or migrate versions just to use these tokens.

## Logo usage guidance
- Use the light-background logo on white or Cloud White surfaces.
- Use the dark-background logo on Midnight Ink or Deep Harbor surfaces.
- Use the mono logo for one-color printing.
- Keep clear space around the logo at least equal to the width of the icon's central vertical stroke.
- Suggested minimum widths: 160 px for the horizontal logo, 80 px for tagline lockups; use the standalone icon below that.
- Do not stretch, rotate, outline, recolor, or add shadows to the logo.
- Electric Aqua is not intended for small text on white; use Midnight Ink or the auxiliary `--dg-aqua-text-on-light` token for legible text links if required.

## Notes

The SVG wordmark is live text rather than a raster embedding, so its exact type rendering depends on the fonts available in the consuming environment. For the most consistent appearance across environments, use a system sans-serif stack or convert text to paths only in a separate release-specific copy.
