---
name: Urban Hydro-Intelligence
colors:
  surface: '#0c1321'
  surface-dim: '#0c1321'
  surface-bright: '#323949'
  surface-container-lowest: '#070e1c'
  surface-container-low: '#151b2a'
  surface-container: '#19202e'
  surface-container-high: '#232a39'
  surface-container-highest: '#2e3544'
  on-surface: '#dce2f6'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#dce2f6'
  inverse-on-surface: '#2a3040'
  outline: '#87929a'
  outline-variant: '#3e484f'
  surface-tint: '#7bd0ff'
  primary: '#8ed5ff'
  on-primary: '#00354a'
  primary-container: '#38bdf8'
  on-primary-container: '#004965'
  inverse-primary: '#00668a'
  secondary: '#43e9d4'
  on-secondary: '#003731'
  secondary-container: '#00ccb9'
  on-secondary-container: '#005148'
  tertiary: '#ffbcb7'
  on-tertiary: '#68000a'
  tertiary-container: '#ff938c'
  on-tertiary-container: '#8d0012'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c4e7ff'
  primary-fixed-dim: '#7bd0ff'
  on-primary-fixed: '#001e2c'
  on-primary-fixed-variant: '#004c69'
  secondary-fixed: '#5afae5'
  secondary-fixed-dim: '#30ddc9'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#0c1321'
  on-background: '#dce2f6'
  surface-variant: '#2e3544'
typography:
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
  numeric-metric:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an ultra-refined, mission-critical meteorological and civic infrastructure intelligence platform. Designed for municipal hydro-engineers, civil emergency directors, and field inspection operations, the aesthetic embodies **Precision Civic Technology**. 

The UI blends high-contrast nocturnal cartography with crisp, structural data surfaces. It rejects generic dashboard tropes in favor of an authoritative, command-center aesthetic: deep oceanic dark chrome, razor-sharp technical typography, restrained cyan telemetry glows, and frosted glass floating overlays. Visual feedback conveys urgency without inducing cognitive overload, turning chaotic stormwater surges, basin depths, and culvert flow rates into decisive municipal interventions.

## Colors

The palette derives from oceanic depths, nighttime stormwater telemetry, and clear tactical signal tiers:

- **Primary (`Rain Cyan` - #38BDF8):** Used for focal interactive states, primary active telemetry paths, active sensors, and core interactive chrome.
- **Secondary (`Electric Aqua` - #20D6C2):** Deployed for verified flow conditions, secondary sensor nodes, network connections, and predictive hydro-routing.
- **Tertiary (`Critical Risk` - #EF4444):** Reserved exclusively for severe overflow warnings, immediate asset failure thresholds, and emergency callouts.
- **Neutral (`Midnight Ink` - #0B1220):** Grounding canvas backdrop that ensures true dark-mode immersion and reduces glare in field and operations environments.

### Operational Data & Surface Tiers
- **Deep Harbor (`#142235`):** Base layer for elevated panels, sidebar navigations, and tactical trays.
- **Sub-surface Fill (`rgba(20, 34, 53, 0.72)`): Glassmorphic backdrop with blur for floating tactical overlays.
- **Urban Mist (`#E2E8F0`):** Primary text and vital sensor readouts, offering crisp legibility against dark surfaces.
- **Slate (`#64748B`):** Secondary metadata, inactive states, grid lines, and structural boundaries.
- **Telemetry Risk Scale:**
  - *Low Risk:* `#34D399` (Stable capacity)
  - *Elevated Risk:* `#F5B942` (Threshold advisory)
  - *High Risk:* `#FB7185` (Capacity compromised)
  - *Critical Risk:* `#EF4444` (Severe active waterlogging)

## Typography

The typographic system balances commanding civic authority with dense scientific readability. 

- **Headlines (Hanken Grotesk):** Engineered geometry with high x-height and tight tracking. Used for page titles, mission overviews, and modal headers.
- **Body & Metrics (Geist):** Clean, technical, neutral typeface optimized for high-density information architecture. 
- **Tabular Numerals:** All real-time telemetry metrics, millimetric rain gauges, coordinate points, and catchment sensor percentages must enforce `font-feature-settings: "tnum" on, "zero" on` to prevent layout reflow during live data streaming.

## Layout & Spacing

The layout is built upon an adaptive 12-column fluid grid tailored for tactical command screens, split-pane GIS views, and responsive tablet field-gear interfaces:

- **Desktop (1024px+):** 12-column layout with 24px gutters and 32px screen margin. Supports a persistent 280px operational utility sidebar, a central geospatial map canvas, and an anchored 360px inspect/telemetry panel.
- **Tablet (768px – 1023px):** 8-column layout with 16px gutters and 24px screen margin. Trays collapse into bottom sheets or layered pull-out inspection rails.
- **Mobile (<768px):** 4-column layout with 16px gutters and 16px screen margin. Direct single-column inspection view with sticky bottom tactical action bar.

Spacing follows a strict 4px/8px modular scale. Spacing tokens strictly prescribe layout distances and internal container paddings. Compact component paddings (`space-xs` and `space-sm`) are preferred inside data rows, telemetry tables, and chip badges to ensure maximum spatial efficiency.

## Elevation & Depth

Visual hierarchy leverages high-precision frosted glass, multi-tiered dark surfaces, and subtle hydro-luminescence rather than heavy opaque drop shadows.

- **Level 0 (Map Base / Canvas):** Pure background `#0B1220`.
- **Level 1 (Docked Containers & Sidebars):** `#142235` with a subtle 1px border `rgba(100, 116, 139, 0.2)`.
- **Level 2 (Glassmorphic Floating Panels):** Background `rgba(20, 34, 53, 0.75)` backed by `backdrop-filter: blur(16px)` and an interior highlight border `1px solid rgba(56, 189, 248, 0.18)`. Casts an ambient shadow: `0 12px 32px -4px rgba(0, 0, 0, 0.5)`.
- **Level 3 (Modals & Emergency Alerts):** Background `rgba(15, 23, 42, 0.95)`, framed with risk-colored boundary glows (e.g., `0 0 24px -2px rgba(239, 68, 68, 0.25)` during active critical flood dispatch events).

## Shapes

The interface adopts a disciplined roundedness level (`2`). This provides a refined, technical balance: 8px default radii for cards, inputs, and interactive panels, 16px for larger floating map modules, and 24px for macro sheet overlays. 

Micro-elements such as status indicators and telemetry tags maintain consistent 4px or pill geometry where continuous edge encapsulation improves immediate glanceability.

## Components

### Buttons
- **Primary Action:** Solid Rain Cyan (`#38BDF8`) background, dark Midnight Ink (`#0B1220`) text, `font-weight: 600`. Subtle hover glow `box-shadow: 0 0 16px rgba(56, 189, 248, 0.4)`. Height: 40px (desktop), 48px (mobile touch target).
- **Secondary / Outline:** Transparent fill with `1px solid rgba(56, 189, 248, 0.4)`, text in Rain Cyan. Hover background transitions to `rgba(56, 189, 248, 0.08)`.
- **Danger / Critical:** Solid Critical Red (`#EF4444`) with white text, strictly reserved for dispatch override, emergency evacuation alerts, and hazard shutdowns.

### Risk Chips & Status Badges
- Compact capsules (`border-radius: 9999px`) with 11px uppercase label typography.
- Uses tinted translucent backgrounds (12% opacity) paired with high-contrast text and a 6px glowing status dot:
  - *Low:* `rgba(52, 211, 153, 0.15)` fill, `#34D399` text and dot.
  - *Elevated:* `rgba(245, 185, 66, 0.15)` fill, `#F5B942` text and dot.
  - *High:* `rgba(251, 113, 133, 0.15)` fill, `#FB7185` text and dot.
  - *Critical:* `rgba(239, 68, 68, 0.2)` fill, `#EF4444` text and pulsating dot.

### Telemetry Cards & Metric Panels
- Frosted dark glass containers with `padding: var(--space-md)`.
- Top edge features a hairline gradient stroke from `rgba(56, 189, 248, 0.3)` to transparent.
- Displays label in `label-sm` (`#64748B`), primary sensor readout in `numeric-metric` (`#F8FAFC`), and an inline micro-trend sparkline or capacity delta percentage.

### Input Fields & Search Bars
- Background `rgba(11, 18, 32, 0.8)` with a 1px border of `#64748B` at 40% opacity.
- Focus state activates a sharp `1px solid #38BDF8` ring with `0 0 0 3px rgba(56, 189, 248, 0.15)`.
- Text styled in Geist 14px with `#F8FAFC` input values and `#64748B` placeholders. Prefix icons in `#38BDF8`.

### Inspection Checklists & Toggles
- Custom radios and checkboxes feature `#142235` backgrounds and 1.5px borders in `#64748B`.
- Active check states pop with `#38BDF8` background fill and `#0B1220` glyphs.
- Toggle switches use a slate track that shifts to an illuminated `#20D6C2` when automated sump pumps or sensor feeds are armed.

### Geospatial Callout Nodes
- Floating map pins anchored to asset coordinates. 
- Composed of an inner luminous core, an oscillating radar ripple ring indicating live data polling, and an attached frosted tooltip card detailing station ID, water depth (cm), and run-off velocity.